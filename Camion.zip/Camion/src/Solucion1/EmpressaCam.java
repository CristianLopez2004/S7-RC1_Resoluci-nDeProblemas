package Solucion1;

import java.util.ArrayList;
import java.util.List;

public class EmpressaCam {
    //ARRAYLIS PARA ALMACENAR OOBJETO CAMION Y AGREGAR CAMIONES
    private List<Camion> camiones;

    public EmpressaCam() {
        camiones = new ArrayList<>();
    }

    public void agregarCamion(Camion camion) {
        camiones.add(camion);
    }

    public Camion buscarMejorCamion(int pesoCarga, double distancia) {
        Camion mejorCamion = null;
        double mejorConsumo = Double.MAX_VALUE;

        for (Camion camion : camiones) {
            if (camion.getCapacidadCarga() >= pesoCarga && camion.calcularConsumoTotal(distancia) < mejorConsumo) {
                mejorCamion = camion;
                mejorConsumo = camion.calcularConsumoTotal(distancia);
            }
        }

        return mejorCamion;
    }
}
