package Solucion1;
import javax.swing.*;

public class MainCamion {
    public static void main(String[] args) {
        EmpressaCam emp = new EmpressaCam();

        // aquiu agrefgo camiones
        emp.agregarCamion(new Camion("ECU1030", 500, 0.5));
        emp.agregarCamion(new Camion("ECU2004", 400, 0.35));
        emp.agregarCamion(new Camion("ECU2005", 750, 0.9));
        emp.agregarCamion(new Camion("ECU4080", 1060, 2));


        // El usuario podra ponerle la carga y km
        String pesoCargaStr = JOptionPane.showInputDialog("Ingrese el peso de la carga en kilogramos:");
        int pesoCarga = Integer.parseInt(pesoCargaStr);
        String distanciaStr = JOptionPane.showInputDialog("Ingrese la distancia en kilómetros:");
        double distancia = Double.parseDouble(distanciaStr);

        Camion mejorCamion = emp.buscarMejorCamion( pesoCarga, distancia);

        if (mejorCamion != null) {
            mejorCamion.cargar(pesoCarga);
            JOptionPane.showMessageDialog(null, "El camión " + mejorCamion.getMatricula() + " es el mejor para transportar esta carga.");
            mejorCamion.descargar();
        } else {
            JOptionPane.showMessageDialog(null, "No hay ningún camión disponible para transportar esa carga.");
        }
    }
}
