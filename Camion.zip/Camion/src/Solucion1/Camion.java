package Solucion1;

import javax.swing.*;


public class Camion {
    //DECLARO LA VARIABLES EN PRIVATE PARA QUE SEA ACCESIBLE DENTRO DE LA PROPIA CLASE

    private String matricula;
    private int capacidadCarga;
    private double consumoGasolina;
    private int cargaActual;

    //CONSTRUCTOR

    public Camion(String matricula, int capacidadCarga, double consumoGasolina) {
        this.matricula = matricula;
        this.capacidadCarga = capacidadCarga;
        this.consumoGasolina = consumoGasolina;
        this.cargaActual = 0;
    }
    //MEETTODOSS GETS Y SETS PARA ACCEDER Y MMODIFICAR LOS PRIIVATE

    public String getMatricula() {
        return matricula;
    }

    public int getCapacidadCarga() {
        return capacidadCarga;
    }

    public double getConsumoGasolina() {
        return consumoGasolina;
    }

    public int getCargaActual() {
        return cargaActual;
    }
    //METODOS

    public void cargar(int carga) {
        if (cargaActual + carga <= capacidadCarga) {
            cargaActual += carga;
            JOptionPane.showMessageDialog(null, "Carga exitosa. Carga actual: " + cargaActual + " kg.");
        } else {
            JOptionPane.showMessageDialog(null, "No se puede cargar esa cantidad de carga. Supera la capacidad del camión.");
        }
    }

    public void descargar() {
        cargaActual = 0;
        JOptionPane.showMessageDialog(null, "Descarga exitosa. Carga actual: " + cargaActual + " kg.");
    }

    public double calcularConsumoTotal(double distancia) {
        return consumoGasolina * distancia;
    }
}


