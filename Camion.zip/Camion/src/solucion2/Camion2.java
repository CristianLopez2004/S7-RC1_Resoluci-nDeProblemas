package solucion2;

public class Camion2
{
    //ddeclaro variables
    String matricula;
    int capacidadCarga;
    double consumoGasolina;
    int cargaActual;
    //CONSTRUCTORr
    public Camion2(String matricula, int capacidadCarga, double consumoGasolina) {
        this.matricula = matricula;
        this.capacidadCarga = capacidadCarga;
        this.consumoGasolina = consumoGasolina;
        this.cargaActual = 0;
    }
    //metodo cargarr
    public void cargar(int carga) {
        if (cargaActual + carga <= capacidadCarga) {
            cargaActual += carga;
            System.out.println("Carga exitosa. Carga actual: " + cargaActual + " kg.");
        } else {
            System.out.println("No se puede cargar esa cantidad de carga. Supera la capacidad del camión.");
        }
    }

    // metodo descargar  camion
    public void descargar() {
        cargaActual = 0;
        System.out.println("Descarga exitosa. Carga actual: " + cargaActual + " kg.");
    }

    // Método pconsumo total de gasolina
    public double calcularConsumoTotal(double distancia) {
        return consumoGasolina * distancia;
    }
}
