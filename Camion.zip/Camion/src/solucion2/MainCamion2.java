package solucion2;
import java.util.Scanner;


public class MainCamion2 {
    public static void main(String[] args) {
        EmpressaCam2 empresa = new EmpressaCam2();
        Scanner scanner = new Scanner(System.in);

        // Agregar camiones
        empresa.agregarCamion(new Camion2("ECU2089", 1000, 1.2));
        empresa.agregarCamion(new Camion2("ECU3309", 1300, 1.59));
        empresa.agregarCamion(new Camion2("ECU1820", 777, 0.97));
        empresa.agregarCamion(new Camion2("ECU0001", 1339, 1.63));

        // USUARIO INGRESE EL PESO Y KMM
        System.out.print("Ingrese el peso de la carga en kilogramos: ");
        int pesoCarga = scanner.nextInt();
        System.out.print("Ingrese la distancia en kilómetros: ");
        double distancia = scanner.nextDouble();

        System.out.print("Ingrese la matrícula del camión a cargar: ");
        String matricula = scanner.nextLine();
        System.out.print("Ingrese la carga deseada en kilogramos: ");
        int cargaDeseada = scanner.nextInt();

        empresa.cargarCamion(matricula, cargaDeseada);

        scanner.close();

        // Buscar el mejor camión para transportar la carga
        Camion2 mejorCamion = empresa.buscarMejorCamion(pesoCarga, distancia);

        if (mejorCamion != null) {
            mejorCamion.cargar(pesoCarga);
            System.out.println("El camión " + mejorCamion.matricula + " es el mejor para transportar esta carga.");
            mejorCamion.descargar();
        } else {
            System.out.println("No hay ningún camión disponible para transportar esa carga.");
        }

        scanner.close();
    }
}
