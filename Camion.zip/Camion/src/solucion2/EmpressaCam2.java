package solucion2;

import java.util.ArrayList;
import java.util.List;

public class EmpressaCam2 {
    List<Camion2> camiones;

    public EmpressaCam2() {
        camiones = new ArrayList<>();
    }

    // Método para agregar un camión a la lista de camiones
    public void agregarCamion(Camion2 camion) {
        camiones.add(camion);
    }

    // Método para buscar el mejor camión disponible para transportar una carga determinada
    public Camion2 buscarMejorCamion(int pesoCarga, double distancia) {
        Camion2 mejorCamion = null;
        double mejorConsumo = Double.MAX_VALUE;

        for (Camion2 camion : camiones) {
            if (camion.capacidadCarga >= pesoCarga && camion.calcularConsumoTotal(distancia) < mejorConsumo) {
                mejorCamion = camion;
                mejorConsumo = camion.calcularConsumoTotal(distancia);
            }
        }

        return mejorCamion;
    }
    public void cargarCamion(String matricula, int cargaDeseada) {
        Camion2 camion = null;
        for (Camion2 c : camiones) {
            if (c.matricula.equals(matricula)) {
                camion = c;
                break;
            }
        }

        if (camion != null) {
            if (cargaDeseada <= camion.capacidadCarga) {
                camion.cargar(cargaDeseada);
            } else {
                System.out.println("La carga deseada excede la capacidad del camión.");
            }
        } else {
            System.out.println("No se encontró ningún camión con la matrícula proporcionada.");
        }
    }
}